from brain_games.games import calc


def main():
    calc.go()


if __name__ == "__name__":
    main()
