from brain_games.games import gcd


def main():
    gcd.go()


if __name__ == "__name__":
    main()
