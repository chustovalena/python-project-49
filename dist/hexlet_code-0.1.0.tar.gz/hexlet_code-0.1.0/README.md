### Hexlet tests and linter status:
[![Actions Status](https://github.com/chustovalena/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/chustovalena/python-project-49/actions)

<a href="https://codeclimate.com/github/chustovalena/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/977cbca820f61b731cad/maintainability" /></a>
