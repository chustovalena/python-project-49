from brain_games.games import progression


def main():
    progression.go()


if __name__ == "__name__":
    main()