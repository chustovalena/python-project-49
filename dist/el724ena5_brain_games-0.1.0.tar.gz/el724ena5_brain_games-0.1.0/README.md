### Hexlet tests and linter status:
[![Actions Status](https://github.com/chustovalena/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/chustovalena/python-project-49/actions)

<a href="https://codeclimate.com/github/chustovalena/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/977cbca820f61b731cad/maintainability" /></a>


#### Установить пакет можно командой:
    pip install -i https://test.pypi.org/simple/ el724ena5-brain-games


### Игры

[Проверка на чётность](https://asciinema.org/a/1v06V6AD9Db16cYWgyfCsunjf)

[Калькулятор](https://asciinema.org/a/RiTmxLLaUgLtIxhI5lhxC3ZxT)

[НОД](https://asciinema.org/a/eBZ6nxpRfOWNRgm5QXKdXBMgV)

[Арифметическая прогрессия](https://asciinema.org/a/gZDsRi4z0NMSdZkWW5yumKQA2)

[Простое ли число?](https://asciinema.org/a/iUzHZ6HjjHdXDdUjIAIJxKWLY)
