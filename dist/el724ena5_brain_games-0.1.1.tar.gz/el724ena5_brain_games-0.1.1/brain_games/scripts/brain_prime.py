from brain_games.games import prime


def main():
    prime.go()


if __name__ == "__name__":
    main()
